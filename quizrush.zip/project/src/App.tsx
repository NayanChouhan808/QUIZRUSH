import React, { useState, useCallback } from 'react';
import { Brain, Trophy, Share2, Timer, Crown, Palette, Users, LineChart, Sparkles, Lock } from 'lucide-react';
import { Quiz } from './components/Quiz';
import { questionsData } from './data/questions';
import type { Category, Question, PremiumFeature, Player } from './types';

const categories: Category[] = [
  { id: 'tech', name: 'Tech & Gaming', icon: <Brain size={24} />, color: 'bg-purple-500' },
  { id: 'pop', name: 'Pop Culture', icon: <Share2 size={24} />, color: 'bg-pink-500' },
  { id: 'sports', name: 'Sports', icon: <Trophy size={24} />, color: 'bg-blue-500' },
  { id: 'random', name: 'Random', icon: <Timer size={24} />, color: 'bg-green-500' },
];

const premiumFeatures: PremiumFeature[] = [
  {
    id: 'creator',
    name: 'Custom Quiz Creator',
    description: 'Build and share your own quizzes',
    icon: <Crown size={24} />,
  },
  {
    id: 'analytics',
    name: 'Analytics Dashboard',
    description: 'Track your performance trends',
    icon: <LineChart size={24} />,
  },
  {
    id: 'themes',
    name: 'Theme Customization',
    description: 'Unlock aesthetic themes and skins',
    icon: <Palette size={24} />,
  },
  {
    id: 'friends',
    name: 'Friends Mode',
    description: 'Play head-to-head in real time',
    icon: <Users size={24} />,
    comingSoon: true,
  },
];

const topPlayers: Player[] = [
  { name: 'Nayan', score: 2800, badge: '🏆', isPro: true },
  { name: 'Aditya', score: 2600, badge: '🥈' },
  { name: 'Navneet', score: 2400, badge: '🥉', isPro: true },
];

function App() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentQuestions, setCurrentQuestions] = useState<Question[]>([]);
  const [showQuiz, setShowQuiz] = useState(false);
  const [finalScore, setFinalScore] = useState<number | null>(null);
  const [showProModal, setShowProModal] = useState(false);

  const generateQuiz = useCallback((categoryId: string) => {
    const categoryQuestions = questionsData[categoryId as keyof typeof questionsData];
    const shuffled = [...categoryQuestions].sort(() => Math.random() - 0.5);
    setCurrentQuestions(shuffled);
    setShowQuiz(true);
    setFinalScore(null);
  }, []);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    generateQuiz(categoryId);
  };

  const handleQuizComplete = (score: number) => {
    setShowQuiz(false);
    setFinalScore(score);
  };

  const handleBackToCategories = () => {
    setSelectedCategory(null);
    setShowQuiz(false);
    setFinalScore(null);
  };

  const handlePremiumFeatureClick = () => {
    setShowProModal(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-4">
            QuizRush
          </h1>
          <p className="text-gray-300 text-xl">
            Test your knowledge. Beat the clock. Top the leaderboard.
          </p>
        </header>

        {showQuiz ? (
          <Quiz
            questions={currentQuestions}
            category={selectedCategory!}
            onComplete={handleQuizComplete}
            onBack={handleBackToCategories}
          />
        ) : (
          <>
            {/* Categories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleCategorySelect(category.id)}
                  className={`${
                    category.color
                  } p-6 rounded-xl transition-transform transform hover:scale-105 hover:shadow-xl ${
                    selectedCategory === category.id ? 'ring-4 ring-white' : ''
                  }`}
                >
                  <div className="flex flex-col items-center text-white">
                    {category.icon}
                    <h3 className="mt-4 text-xl font-semibold">{category.name}</h3>
                  </div>
                </button>
              ))}
            </div>

            {/* Premium Features */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Sparkles className="mr-2" /> Premium Features
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {premiumFeatures.map((feature) => (
                  <button
                    key={feature.id}
                    onClick={handlePremiumFeatureClick}
                    className="bg-white/5 p-6 rounded-xl backdrop-blur-lg hover:bg-white/10 transition-all group relative"
                  >
                    <div className="absolute top-3 right-3">
                      <Lock className="text-yellow-400" size={16} />
                    </div>
                    <div className="flex flex-col items-center text-center">
                      <div className="text-yellow-400 mb-4">{feature.icon}</div>
                      <h3 className="text-white font-semibold mb-2">{feature.name}</h3>
                      <p className="text-gray-300 text-sm">{feature.description}</p>
                      {feature.comingSoon && (
                        <span className="mt-2 px-2 py-1 bg-white/10 rounded-full text-xs text-yellow-400">
                          Coming Soon
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {finalScore !== null && (
              <div className="text-center mb-12 p-6 bg-white/10 backdrop-blur-lg rounded-xl">
                <h2 className="text-3xl font-bold text-white mb-4">Quiz Complete! 🎉</h2>
                <p className="text-2xl text-purple-300">Your Score: {finalScore}</p>
              </div>
            )}

            {/* Leaderboard Preview */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Trophy className="mr-2" /> Top Players
              </h2>
              <div className="space-y-4">
                {topPlayers.map((player, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between bg-white/5 p-4 rounded-lg"
                  >
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{player.badge}</span>
                      <div className="flex items-center">
                        <span className="text-white font-medium">{player.name}</span>
                        {player.isPro && (
                          <span className="ml-2 px-2 py-0.5 bg-yellow-400/20 rounded-full text-yellow-400 text-xs font-semibold">
                            PRO
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-purple-300 font-bold">{player.score}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Pro Modal */}
        {showProModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 max-w-md w-full">
              <div className="text-center">
                <Crown className="text-yellow-400 w-16 h-16 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-2">Upgrade to Pro</h3>
                <p className="text-gray-300 mb-6">
                  Unlock all premium features and take your quiz experience to the next level!
                </p>
                <button
                  onClick={() => setShowProModal(false)}
                  className="w-full py-3 px-6 bg-yellow-400 text-black rounded-lg font-semibold hover:bg-yellow-300 transition-colors mb-4"
                >
                  Upgrade Now
                </button>
                <button
                  onClick={() => setShowProModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Maybe Later
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <footer className="mt-12 text-center text-gray-400">
          <p>Created with 💜 by Nayan, Aditya, and Navneet</p>
        </footer>
      </div>
    </div>
  );
}

export default App;