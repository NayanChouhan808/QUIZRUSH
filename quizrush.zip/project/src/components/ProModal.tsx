import React, { useState } from 'react';
import { Crown } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { AuthModal } from './AuthModal';
import { supabase } from '../lib/supabase';

type ProModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function ProModal({ isOpen, onClose }: ProModalProps) {
  const [showAuth, setShowAuth] = useState(false);
  const { user, checkProStatus } = useAuthStore();

  const handleUpgrade = async () => {
    if (!user) {
      setShowAuth(true);
      return;
    }

    try {
      // Insert a new subscription record with active status
      const { error } = await supabase
        .from('subscriptions')
        .insert({
          user_id: user.id,
          status: 'active',
          stripe_customer_id: 'free_upgrade',
          stripe_subscription_id: 'free_upgrade'
        });

      if (error) throw error;

      // Update local pro status
      await checkProStatus();
      
      alert('Successfully upgraded to Pro! Enjoy all premium features!');
      onClose();
    } catch (error) {
      console.error('Upgrade error:', error);
      alert('Upgrade failed. Please try again.');
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 max-w-md w-full">
          <div className="text-center">
            <Crown className="text-yellow-400 w-16 h-16 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">Upgrade to Pro</h3>
            <p className="text-gray-300 mb-6">
              Unlock all premium features and take your quiz experience to the next level!
            </p>
            <ul className="text-left mb-6 space-y-2">
              <li className="flex items-center text-white">
                <span className="mr-2">✓</span> Create custom quizzes
              </li>
              <li className="flex items-center text-white">
                <span className="mr-2">✓</span> Access detailed analytics
              </li>
              <li className="flex items-center text-white">
                <span className="mr-2">✓</span> Unlock all themes
              </li>
              <li className="flex items-center text-white">
                <span className="mr-2">✓</span> Play with friends
              </li>
            </ul>
            <button
              onClick={handleUpgrade}
              className="w-full py-3 px-6 bg-yellow-400 text-black rounded-lg font-semibold hover:bg-yellow-300 transition-colors mb-4"
            >
              Upgrade Now - Free!
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Maybe Later
            </button>
          </div>
        </div>
      </div>
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} mode="signup" />
    </>
  );
}