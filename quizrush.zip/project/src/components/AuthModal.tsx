import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';

type AuthModalProps = {
  isOpen: boolean;
  onClose: () => void;
  mode?: 'signin' | 'signup';
};

export function AuthModal({ isOpen, onClose, mode = 'signin' }: AuthModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignIn, setIsSignIn] = useState(mode === 'signin');
  const { signIn, signUp } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isSignIn) {
        await signIn(email, password);
      } else {
        await signUp(email, password);
      }
      onClose();
    } catch (error) {
      console.error('Auth error:', error);
      alert('Authentication failed. Please try again.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-8 max-w-md w-full">
        <h2 className="text-2xl font-bold text-white mb-6">
          {isSignIn ? 'Sign In' : 'Create Account'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-white mb-2" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 rounded bg-white/10 text-white border border-white/20"
              required
            />
          </div>
          <div>
            <label className="block text-white mb-2" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 rounded bg-white/10 text-white border border-white/20"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors"
          >
            {isSignIn ? 'Sign In' : 'Sign Up'}
          </button>
        </form>
        <button
          onClick={() => setIsSignIn(!isSignIn)}
          className="mt-4 text-purple-300 hover:text-purple-200 transition-colors text-sm"
        >
          {isSignIn ? "Don't have an account? Sign Up" : 'Already have an account? Sign In'}
        </button>
      </div>
    </div>
  );
}