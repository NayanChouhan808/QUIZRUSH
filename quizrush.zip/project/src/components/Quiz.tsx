import React, { useState, useEffect } from 'react';
import { Timer, ArrowLeft } from 'lucide-react';
import { Question } from '../types';

type QuizProps = {
  questions: Question[];
  category: string;
  onComplete: (score: number) => void;
  onBack: () => void;
};

export function Quiz({ questions, category, onComplete, onBack }: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isAnswered, setIsAnswered] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];

  useEffect(() => {
    if (timeLeft > 0 && !isAnswered) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !isAnswered) {
      handleNextQuestion();
    }
  }, [timeLeft, isAnswered]);

  const handleAnswerSelect = (answer: string) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    if (answer === currentQuestion.correctAnswer) {
      setScore(score + Math.ceil(timeLeft / 3));
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setTimeLeft(30);
      setIsAnswered(false);
    } else {
      onComplete(score);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white/10 backdrop-blur-lg rounded-xl p-6">
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={onBack}
          className="text-white hover:text-purple-300 transition-colors"
        >
          <ArrowLeft size={24} />
        </button>
        <div className="flex items-center text-white">
          <Timer className="mr-2" />
          <span className="font-mono text-xl">{timeLeft}s</span>
        </div>
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <span className="text-purple-300">
            Question {currentQuestionIndex + 1}/{questions.length}
          </span>
          <span className="text-purple-300">Score: {score}</span>
        </div>
        <h2 className="text-2xl font-bold text-white mb-6">{currentQuestion.question}</h2>
        <div className="grid gap-4">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(option)}
              className={`p-4 rounded-lg text-left transition-all transform hover:scale-102 ${
                isAnswered
                  ? option === currentQuestion.correctAnswer
                    ? 'bg-green-500 text-white'
                    : option === selectedAnswer
                    ? 'bg-red-500 text-white'
                    : 'bg-white/5 text-white'
                  : 'bg-white/5 text-white hover:bg-white/10'
              }`}
              disabled={isAnswered}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {isAnswered && (
        <button
          onClick={handleNextQuestion}
          className="w-full py-3 px-6 bg-purple-500 text-white rounded-lg font-semibold hover:bg-purple-600 transition-colors"
        >
          {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
        </button>
      )}
    </div>
  );
}