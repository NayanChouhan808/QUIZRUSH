export type Question = {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  category: string;
};

export type Category = {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
};

export type PremiumFeature = {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  comingSoon?: boolean;
};

export type Player = {
  name: string;
  score: number;
  badge: string;
  isPro?: boolean;
};