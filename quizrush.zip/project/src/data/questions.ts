export const questionsData = {
  tech: [
    {
      id: '1',
      question: 'What does AI stand for?',
      options: ['Artificial Intelligence', 'Automated Interface', 'Advanced Integration', 'Algorithmic Implementation'],
      correctAnswer: 'Artificial Intelligence',
      category: 'tech'
    },
    {
      id: '2',
      question: 'Which company created React?',
      options: ['Google', 'Facebook', 'Amazon', 'Microsoft'],
      correctAnswer: 'Facebook',
      category: 'tech'
    },
    {
      id: '3',
      question: 'What is the latest version of iPhone?',
      options: ['iPhone 14', 'iPhone 15', 'iPhone 13', 'iPhone 12'],
      correctAnswer: 'iPhone 15',
      category: 'tech'
    }
  ],
  pop: [
    {
      id: '4',
      question: 'Who has the most followers on Instagram?',
      options: ['Cristiano Ronaldo', 'Lionel Messi', 'Kylie Jenner', 'Selena Gomez'],
      correctAnswer: 'Cristiano Ronaldo',
      category: 'pop'
    },
    {
      id: '5',
      question: 'Which song was Spotify\'s most streamed in 2023?',
      options: ['Flowers', 'Last Night', 'Anti-Hero', 'Cruel Summer'],
      correctAnswer: 'Flowers',
      category: 'pop'
    },
    {
      id: '6',
      question: 'Which movie won Best Picture at the 2024 Oscars?',
      options: ['Oppenheimer', 'Barbie', 'Killers of the Flower Moon', 'Poor Things'],
      correctAnswer: 'Oppenheimer',
      category: 'pop'
    }
  ],
  sports: [
    {
      id: '7',
      question: 'Which country won the 2023 Cricket World Cup?',
      options: ['India', 'Australia', 'England', 'New Zealand'],
      correctAnswer: 'Australia',
      category: 'sports'
    },
    {
      id: '8',
      question: 'Who won the 2023 F1 World Championship?',
      options: ['Max Verstappen', 'Lewis Hamilton', 'Charles Leclerc', 'Sergio Perez'],
      correctAnswer: 'Max Verstappen',
      category: 'sports'
    },
    {
      id: '9',
      question: 'Which team won the Super Bowl LVIII (2024)?',
      options: ['Kansas City Chiefs', 'San Francisco 49ers', 'Philadelphia Eagles', 'Baltimore Ravens'],
      correctAnswer: 'Kansas City Chiefs',
      category: 'sports'
    }
  ],
  random: [
    {
      id: '10',
      question: 'What is the capital of Australia?',
      options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'],
      correctAnswer: 'Canberra',
      category: 'random'
    },
    {
      id: '11',
      question: 'How many elements are in the periodic table?',
      options: ['118', '119', '120', '117'],
      correctAnswer: '118',
      category: 'random'
    },
    {
      id: '12',
      question: 'Which planet is known as the Red Planet?',
      options: ['Venus', 'Mars', 'Jupiter', 'Mercury'],
      correctAnswer: 'Mars',
      category: 'random'
    }
  ]
};